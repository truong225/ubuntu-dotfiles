static const char* selbgcolor   = "{color0}";
static const char* selfgcolor   = "{color15}";
static const char* normbgcolor  = "{color2}";
static const char* normfgcolor  = "{color15}";
static const char* urgbgcolor   = "{color1}";
static const char* urgfgcolor   = "{color15}";
